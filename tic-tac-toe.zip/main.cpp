#include <cstdlib>
#include <iostream>


using namespace std;

const int SIZE=3;
char space [3][3]= {{'1','2','3'},{'4','5','6'},{'7','8','9'}};


void DisplayBoard() {

	cout<<"    |     |    "<<endl;
	cout<<"  "<<space[0][0]<<" |  "<<space[0][1]<<"  |  "<<space[0][2]<<endl;
	cout<<"____|_____|____"<<endl;
	cout<<"    |     |    "<<endl;
	cout<<" "<<space[1][0]<<"  |  "<<space[1][1]<<"  |  "<<space[1][2]<<endl;
	cout<<"____|_____|____"<<endl;
	cout<<"    |     |    "<<endl;
	cout<<" "<<space[2][0]<<"  |  "<<space[2][1]<<"  |  "<<space[2][2]<<endl;
	cout<<"    |     |    "<<endl;


}

bool IsValid(int row,int col){
    return space[row][col] != 'X' && space[row][col] != 'O';
}

void Turn(char mark) {
	int input,row,col;
	cout<<"Enter the number where you want to place your mark:";
	cin>>input;
	row= (input - 1) / SIZE;
	col=(input - 1) %SIZE;//validation to be done here
	while (!IsValid(row, col)) {
        cout << "Mark already placed there or invalid position, select a different number (1-9): ";
        cin >> input;
        row = (input - 1) / SIZE;
        col = (input - 1) % SIZE;
    }
	space[row][col]=mark;
	system("clear");
	DisplayBoard();
}

bool CheckWin(char mark) {
// Check rows
	for (int i = 0; i < SIZE; ++i) {
		if (space[i][0] == mark && space[i][1] == mark && space[i][2] == mark) {
			return true;
		}
	}

	// Check columns
	for (int j = 0; j < SIZE; ++j) {
		if (space[0][j] == mark && space[1][j] == mark && space[2][j] == mark) {
			return true;
		}
	}

	// Check diagonals
	if (space[0][0] == mark && space[1][1] == mark && space[2][2] == mark) {
		return true;
	}
	if (space[0][2] == mark && space[1][1] == mark && space[2][0] == mark) {
		return true;
	}

	// No winner found
	return false;
}


int main()
{

	string p1,p2;
	int turn_counter=1;
	cout<<"Enter name of first player:";
	getline(cin,p1);
	cout<<"Enter name of second player:";
	getline(cin,p2);
	DisplayBoard();
	do {
		if(turn_counter%2==1) {
		    cout<<p1<<"'s turn"<<endl;
			Turn('X');
			if(turn_counter>5)
			{
				if (CheckWin('X')) {
					DisplayBoard();
					cout << "Player 1 wins!" << endl;
					return 0;
				}
			
			}
			turn_counter++;
			
			
		}
			else if (turn_counter%2==0) {
				cout<<p2<<"'s turn"<<endl;
				Turn('O');
				
				
				if(turn_counter>5)
				{
					if (CheckWin('O')) {
						DisplayBoard();
						cout << "Player 2 wins!" << endl;
						return 0;
					}
				}
				    turn_counter++;
				    
				
			}
		}
		while(turn_counter<=9);
	cout<<"Game draw!";
}
	

