
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{

	srand(static_cast<unsigned>(time(0)));
	char input;

	bool start="true";
	while (start) {
		cout<<endl<<"\tWelcome to the game!Please select one of the options:"<<endl;
		cout << "\t--> Start new game (n) \n";
		cout << "\t--> Quit (q) \n\n";
		cin>>input;

		if (input=='n')
		{
			int random_number= rand()%101;
			cout<<"Random number has been generated!"<<endl<<"Guess a number between 1-100(inclusive):";
			int guess;
			cin>>guess;
			while(guess != random_number)
			{

				if(guess>101)
				{
					cout<<"Number not in range!! Try again"<<endl;
					cin>>guess;
					if(guess==random_number)
					{
						cout<<"Congratulation!! You have won the game!!"<<endl;
						break;
					}
				}


				else if(guess<random_number)
				{
					cout<<"You need to guess a number that is higher!"<<endl;
					cin>>guess;
					if(guess==random_number)
					{
						cout<<"Congratulation!! You have won the game!!"<<endl;
						break;
					}
				}
				else if(guess>random_number)
				{
					cout<<"You need to guess a number that is lower!"<<endl;
					cin>>guess;
					if(guess==random_number)
					{
						cout<<"Congratulation!! You have won the game!!"<<endl;
						break;

					}

				}

			}
		}

		if (input=='q')
		{
			start="false";
			break;
		}



	}
}