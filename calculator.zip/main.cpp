#include <iostream>

using namespace std;

void DisplayResult(float num1, float num2, float result, char operation){
  cout<<"The result of "<<num1<<" "<< operation <<" " << num2<<" is "<<result;
};

int main()
{
	cout<<"Calculator"<<endl;
	char operation;
	float num1, num2,result;
	cout<<"Enter 1st number:";
	cin>>num1;
	cout<<"Enter 2nd number:";
	cin>>num2;
	do {
		cout<<"Select operation you want to perform( + , - , / , * ):";
		cin>> operation;
		if (operation != '+' && operation != '-' && operation != '*' && operation != '/') {
			cout << "Invalid input. Try again!" << endl;
		}
	}
	while(operation != '+' && operation != '-' && operation != '*' && operation != '/');
    
    switch(operation)
		{
		case '+':
			result=num1+num2;
			DisplayResult(num1,num2,result,operation);
			break;

		case '-':
			result=num1-num2;
			DisplayResult(num1,num2,result,operation);
			break;

		case '/':
			if(num2==0)
			{
				cout<<"Synatx Error";
			}
			else {
				result=num1/num2;
				DisplayResult(num1,num2,result,operation);
				break;
			}

		case '*':
			result=num1*num2;
			DisplayResult(num1,num2,result,operation);
			break;

			return 0;
		}
}